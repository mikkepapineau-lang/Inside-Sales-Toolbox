(()=>{
const el=id=>document.getElementById(id),M=ContactModel;
let restoring=true;
function persist(){
 if(restoring)return;
 const snapshot={raw:el('contact-raw').value,...draft(),warning:el('contact-warning').textContent};
 chrome.storage.local.set({toolboxContacts:snapshot}).catch(()=>{el('contact-status').textContent='Impossible de conserver les coordonnées. Copie-les avant de fermer.';});
}
function module(name){
 if(!['home','bridge','contacts','hs'].includes(name))name='home';
 if(!restoring)chrome.storage.local.set({toolboxModule:name});
 if(name==='hs'&&!el('hs-frame').src)el('hs-frame').src='hs/popup.html';
 el('tool-home-panel').hidden=name!=='home';
 for(const n of ['bridge','contacts','hs'])el('tool-'+n).hidden=n!==name;
 el('tool-home').hidden=name==='home';
 el('tool-label').textContent={home:'Tes outils de ventes internes',bridge:'Salesforce vers Dynamics',contacts:'Coordonnées client',hs:'Vérificateur HS'}[name];
}
el('tool-home').onclick=()=>module('home');
for(const b of document.querySelectorAll('[data-module]'))b.onclick=async()=>{
 if(b.dataset.module==='hs'){
 const ok=await chrome.permissions.contains({origins:['https://www.canada.ca/*']});
 module('hs');if(!el('hs-frame').src)el('hs-frame').src='hs/popup.html';
 if(!ok)el('tool-label').textContent='Vérificateur HS · actualisation non autorisée';
 }else module(b.dataset.module);
};
function draft(){return {name:el('contact-name').value,phone:el('contact-phone').value,email:el('contact-email').value};}
function preview(){try{el('contact-preview').value=M.values(draft()).notes;}catch{el('contact-preview').value='';}}
function fillEditor(d){for(const k of ['name','phone','email'])el('contact-'+k).value=d[k]||'';preview();}
el('contact-parse').onclick=()=>{const d=M.parse(el('contact-raw').value);fillEditor(d);el('contact-warning').textContent=d.warnings.join(' ');el('contact-status').textContent='Vérifie les trois champs avant de les appliquer.';persist();};
for(const k of ['name','phone','email'])el('contact-'+k).oninput=()=>{preview();el('contact-status').textContent='';persist();};
el('contact-raw').oninput=persist;
function normalized(){const v=M.values(draft());fillEditor(v);persist();return v;}
el('contact-copy').onclick=async()=>{try{await ToolboxAccess.requireAccess({permissions:['clipboardWrite']},'presse-papiers');await navigator.clipboard.writeText(normalized().notes);el('contact-status').textContent='Notes copiées.';}catch(e){el('contact-status').textContent=e.message;}};
el('contact-fill').onclick=async()=>{
 const b=el('contact-fill');b.disabled=true;
 try{
 const v=normalized();await ToolboxAccess.requireAccess({origins:['https://solotech.operations.dynamics.com/*']},'Dynamics 365');const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 if(!tab?.id||new URL(tab.url).hostname!=='solotech.operations.dynamics.com')throw Error('Ouvre l’extension depuis ta soumission ou commande D365.');
 await chrome.scripting.executeScript({target:{tabId:tab.id},files:['d365-controls.js','contact-fill.js']});
 const [r]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:async values=>{try{return {value:await globalThis.fillClientContacts(values)};}catch(e){return {error:e.message};}},args:[v]});
 if(r.result?.error)throw Error(r.result.error);
 if(!r.result?.value)throw Error('Aucune confirmation reçue. Vérifie les champs dans D365.');
 el('contact-status').textContent=r.result.value.report.join(', ')+' remplis. Vérifie puis enregistre dans D365.';
 }catch(e){el('contact-status').textContent=e.message;}finally{b.disabled=false;}
};
el('contact-clear').onclick=()=>{fillEditor({});el('contact-raw').value='';el('contact-warning').textContent='';el('contact-status').textContent='Coordonnées effacées.';persist();};
module('home');
const inputs=['contact-raw','contact-name','contact-phone','contact-email','contact-parse','contact-clear','contact-copy','contact-fill'];
for(const id of inputs)el(id).disabled=true;
chrome.storage.local.get(['toolboxModule','toolboxContacts']).then(saved=>{
 const d=saved.toolboxContacts;
 if(d){el('contact-raw').value=d.raw||'';fillEditor(d);el('contact-warning').textContent=d.warning||'';}
 module(saved.toolboxModule||'home');
}).catch(()=>{el('contact-status').textContent='Impossible de restaurer les coordonnées.';}).finally(()=>{restoring=false;for(const id of inputs)el(id).disabled=false;});
})();
