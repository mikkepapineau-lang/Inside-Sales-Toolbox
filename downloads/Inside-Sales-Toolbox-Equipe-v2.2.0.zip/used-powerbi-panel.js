(()=>{
 const el=id=>document.getElementById(id);let data=null,status={};
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 const numeric=s=>{const v=String(s||'').replace(/[\s\u00a0\u202f]/g,'');return /^-?\d+(?:[.,]\d+)?$/.test(v)?Number(v.replace(',','.')):null;};
 function render(){
  const root=el('used-results');root.replaceChildren();el('used-refresh').disabled=status.state==='loading';
  el('used-status').textContent=status.state==='loading'?'Lecture de l’inventaire usagé…':status.state==='error'?status.message:data?'Lecture terminée.':'Clique sur Actualiser pour récupérer le catalogue usagé.';
  el('used-time').textContent=data?new Date(data.at).toLocaleString(document.documentElement.lang==='en'?'en-CA':'fr-CA'):'';
  if(!data){el('used-count').textContent='';return;}
  const headers=data.headers.map(norm),index=rx=>headers.findIndex(v=>rx.test(v));
  const cols={item:index(/^(d365itemid|d365itemnumber|itemnumber)$/),sku:index(/^sku$/),description:index(/^description$/),brand:index(/^manufacturer$/),category:index(/^category$/),sub:index(/^subcategory$/),available:index(/^qtyavailable$/),owned:index(/^qtyowned$/),sellable:index(/^maxqtytosell$/),price:index(/^sellprice$/),model:index(/^model$/)};
  const get=(r,key)=>cols[key]>=0?r.values[cols[key]]||'':'';
  const query=norm(el('used-query').value),availableOnly=el('used-available').checked;
  const records=data.rows.filter(r=>(!query||norm(r.values.join(' ')).includes(query))&&(!availableOnly||numeric(get(r,'available'))>0));
  const groups=new Map();records.forEach((r,i)=>{const key=get(r,'item').trim()?'item:'+get(r,'item').trim():'sku:'+get(r,'sku')+':'+i;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);});
  el('used-count').textContent=groups.size+' article(s) · '+records.length+' / '+data.rows.length+' ligne(s)';
  el('used-currency').textContent=data.currency||'Devise à vérifier';
  for(const rows of groups.values()){
   const r=rows[0],card=node('article','product-card used-card'),head=node('div','product-card-heading');head.append(node('h3','product-sku',get(r,'sku')||get(r,'item')));
   head.append(node('span','product-stock-badge'+(rows.some(r=>numeric(get(r,'available'))>0)?' product-stock-positive':''),rows.some(r=>numeric(get(r,'available'))>0)?'Disponible':'À vérifier'));card.append(head);
   card.append(node('p','product-meta',[get(r,'brand'),get(r,'item')?'D365 '+get(r,'item'):''].filter(Boolean).join(' · ')));
   if(get(r,'description'))card.append(node('p','product-description',get(r,'description')));
   rows.forEach((r,i)=>{
    if(rows.length>1)card.append(node('p','product-meta','Ligne source '+(i+1)));
    const dl=node('dl','product-metrics product-warehouse-metrics');
    for(const [key,label] of [['available','Disponible'],['price','Prix de vente'],['owned','Quantité possédée'],['sellable','Maximum à vendre']])if(get(r,key)!==''){
     const box=node('div',key==='available'?'product-available-metric':'');box.append(node('dt','',label),node('dd','',get(r,key)+(key==='price'&&data.currency?' '+data.currency:'')));dl.append(box);
    }card.append(dl);
   });
   const detail=node('details','product-details');detail.append(node('summary','','Toutes les informations'));const source=node('div','product-source-lines');
   for(const r of rows){const fields=node('dl','product-all-values');data.headers.forEach((h,i)=>{if(r.values[i]){const pair=node('div','');pair.append(node('dt','',h),node('dd','',r.values[i]));fields.append(pair);}});source.append(fields);
    if(r.href){try{const u=new URL(r.href);if(u.protocol==='https:'&&!u.username&&!u.password){const a=node('a','used-source-link','Ouvrir le lien SKU ↗');a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';source.append(a);}}catch{}}
   }detail.append(source);card.append(detail);root.append(card);
  }
  if(!records.length)root.append(node('p','muted','Aucun article ne correspond aux filtres locaux.'));
 }
 async function action(kind){try{const r=await chrome.runtime.sendMessage({kind});if(r?.error)throw Error(r.error);if(kind==='usedPowerBIDiagnostic'){el('used-diagnostic-output').hidden=false;el('used-diagnostic-output').value=JSON.stringify(r.value,null,2);}if(kind==='usedPowerBIBind')el('used-status').textContent='Onglet associé. Clique sur Actualiser.';}catch(e){el('used-status').textContent=e.message;}}
 el('used-refresh').onclick=()=>action('usedPowerBIRead');el('used-open').onclick=()=>action('usedPowerBIOpen');el('used-bind').onclick=()=>action('usedPowerBIBind');el('used-diagnostic').onclick=()=>action('usedPowerBIDiagnostic');
 el('used-query').oninput=render;el('used-available').onchange=render;
 el('used-clear').onclick=async()=>{await chrome.storage.local.remove('toolboxUsedPowerBI');data=null;render();};
 chrome.storage.onChanged.addListener((c,area)=>{if(area!=='local')return;let changed=false;if(c.toolboxUsedPowerBI){data=c.toolboxUsedPowerBI.newValue;changed=true;}if(c.toolboxUsedPowerBIStatus){status=c.toolboxUsedPowerBIStatus.newValue||{};changed=true;}if(c.toolboxUsedPowerBIDiagnostic){el('used-diagnostic-output').hidden=false;el('used-diagnostic-output').value=JSON.stringify(c.toolboxUsedPowerBIDiagnostic.newValue,null,2);}if(changed)render();});
 chrome.storage.local.get(['toolboxUsedPowerBI','toolboxUsedPowerBIStatus']).then(s=>{data=s.toolboxUsedPowerBI;status=s.toolboxUsedPowerBIStatus||{};render();});
})();
