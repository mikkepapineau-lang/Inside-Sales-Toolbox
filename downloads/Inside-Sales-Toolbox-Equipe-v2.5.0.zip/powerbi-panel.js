(()=>{
 const el=id=>document.getElementById(id);let data=null,status={},filter='';
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const {node,row:recordRow,fieldList,diagnostics,time}=ToolboxList;
 function render(){
  const root=el('powerbi-results');root.replaceChildren();el('powerbi-refresh').disabled=status.state==='loading';
  el('powerbi-status').textContent=status.state==='loading'?'Lecture du rapport Power BI…':status.state==='error'?status.message:data?'Lecture terminée.':'Clique sur Actualiser. Ready to PIK sera sélectionné automatiquement dans le rapport.';
  el('powerbi-status').dataset.state=status.state||'idle';
  el('powerbi-status').hidden=!!data&&status.state!=='loading'&&status.state!=='error';
  if(!data)return;
  el('powerbi-freshness').textContent=time(data.at);
  const keys=data.headers.map(h=>norm(h).replace(/[^a-z0-9]/g,''));
  const find=rx=>keys.findIndex(v=>rx.test(v));
  const col={order:find(/^(salesordernumber|sonumber|numerodecommande|numerocommande)$/),customer:find(/^(customer|client)$/),amount:find(/^(totalnotinvoiced|totalnonfacture)$/),qty:find(/^(physicalreserveqty|quantitereserveephysiquement)$/),delivery:find(/^(modeofdelivery|modedelivraison)$/),payment:find(/^(payment|paiement)$/),status:find(/^status$/),rep:find(/^(salesrepname|representant)$/),ref:find(/^customerreference$/),po:find(/^customerrequisition$/),project:find(/^projectid$/)};
  const val=(r,k)=>col[k]>=0?r.values[col[k]]||'':'';
  const rep=el('powerbi-rep').value,query=norm(filter);
  const list=data.rows.filter(r=>(!rep||val(r,'rep')===rep)&&(!query||norm(r.values.join(' ')).includes(query)));
  el('powerbi-count').textContent=list.length+' / '+data.rows.length;
  for(const r of list){
   const meta=[];
   for(const [key,label] of [['delivery',''],['payment',''],['qty','Réservé']])if(val(r,key))meta.push({label,value:val(r,key)});
   const record=recordRow({key:'order:'+val(r,'order'),code:val(r,'order'),name:val(r,'customer'),amount:val(r,'amount'),href:r.href,host:'solotech.operations.dynamics.com',meta});
   record.append(fieldList(data.headers,r.values));root.append(record);
  }
  if(!list.length)root.append(node('p','muted','Aucune commande ne correspond aux filtres locaux.'));
 }
 function reps(){const selected=el('powerbi-rep').value;el('powerbi-rep').replaceChildren(node('option','','Tous les représentants'));el('powerbi-rep').firstChild.value='';if(data){const i=data.headers.findIndex(h=>norm(h).replace(/[^a-z0-9]/g,'')==='salesrepname');for(const v of [...new Set(data.rows.map(r=>r.values[i]).filter(Boolean))].sort()){const o=node('option','',v);o.value=v;el('powerbi-rep').append(o);}}el('powerbi-rep').value=selected;}
 async function action(kind){try{const r=await chrome.runtime.sendMessage({kind});if(r?.error)throw Error(r.error);if(kind==='powerBIDiagnostic'){diagnostics('powerbi-diagnostic-output',r.value);}if(kind==='powerBIBind')el('powerbi-status').textContent='Onglet associé. Clique sur Actualiser.';}catch(e){el('powerbi-status').textContent=e.message;}}
 el('powerbi-refresh').onclick=()=>action('powerBIRead');el('powerbi-open').onclick=()=>action('powerBIOpen');el('powerbi-diagnostic').onclick=()=>action('powerBIDiagnostic');
 el('powerbi-bind').onclick=()=>action('powerBIBind');
 el('powerbi-query').oninput=()=>{filter=el('powerbi-query').value;render();};el('powerbi-rep').onchange=()=>{chrome.storage.local.set({toolboxPowerBIRep:el('powerbi-rep').value});render();};
 el('powerbi-clear').onclick=async()=>{await chrome.storage.local.remove('toolboxPowerBI');data=null;el('powerbi-freshness').textContent='';el('powerbi-count').textContent='';reps();render();};
 chrome.storage.onChanged.addListener((c,area)=>{if(area!=='local')return;let changed=false;if(c.toolboxPowerBI){data=c.toolboxPowerBI.newValue;reps();changed=true;}if(c.toolboxPowerBIStatus){status=c.toolboxPowerBIStatus.newValue||{};changed=true;}if(c.toolboxPowerBIDiagnostic){diagnostics('powerbi-diagnostic-output',c.toolboxPowerBIDiagnostic.newValue);}if(changed)render();});
 chrome.storage.local.get(['toolboxPowerBI','toolboxPowerBIStatus','toolboxPowerBIRep']).then(s=>{data=s.toolboxPowerBI;status=s.toolboxPowerBIStatus||{};reps();el('powerbi-rep').value=s.toolboxPowerBIRep||'';render();});
})();
