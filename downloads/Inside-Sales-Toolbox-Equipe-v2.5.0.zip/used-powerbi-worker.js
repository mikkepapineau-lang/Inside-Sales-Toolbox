const USED_POWERBI_REPORT_URL='https://app.powerbi.com/groups/ff3be965-02e9-4c0f-b9eb-b73e3bb4e51f/reports/458f40a9-2b3f-4518-a3cb-d699fef65baa/ReportSection7cb28c98171347d49c0a?ctid=c2f120b6-e8fc-402c-9972-fa891cb53927&experience=power-bi';
let usedPowerBIBusy=false,usedPowerBIStop=false;
let usedCatalogueInit=null;
async function initialUsedCatalogue(){
 const response=await fetch(chrome.runtime.getURL('used-catalogue-base.json'));
 if(!response.ok)throw Error('Le catalogue Excel initial ne peut pas être chargé. Recharge l’extension.');
 return ToolboxUsedCatalogue.create(await response.json(),{at:0,source:'Excel initial',batch:'excel-2026-10-15'});
}
async function ensureUsedCatalogue(){
 if(usedCatalogueInit)return usedCatalogueInit;
 usedCatalogueInit=(async()=>{
  const saved=await chrome.storage.local.get('toolboxUsedPowerBI');
  if(saved.toolboxUsedPowerBI?.schemaVersion===1)return saved.toolboxUsedPowerBI;
  let data=await initialUsedCatalogue();
  if(saved.toolboxUsedPowerBI?.rows?.length){
   try{data=ToolboxUsedCatalogue.merge(data,saved.toolboxUsedPowerBI,{at:saved.toolboxUsedPowerBI.at||Date.now(),source:'Power BI'});}catch{}
  }
  await chrome.storage.local.set({toolboxUsedPowerBI:data});return data;
 })();
 try{return await usedCatalogueInit;}finally{usedCatalogueInit=null;}
}
const isUsedPowerBI=tab=>{try{return new URL(tab.url).origin==='https://app.powerbi.com'&&new URL(tab.url).pathname.includes('/reports/458f40a9-2b3f-4518-a3cb-d699fef65baa/');}catch{return false;}};
async function usedPowerBITab(){
 const saved=await chrome.storage.session.get(['usedPowerBITab','usedPowerBIResolvedURL']);
 let tab;try{if(saved.usedPowerBITab)tab=await chrome.tabs.get(saved.usedPowerBITab);}catch{}
 if(!isUsedPowerBI(tab))tab=null;
 if(!tab){const tabs=await chrome.tabs.query({url:'https://app.powerbi.com/*'});const matches=tabs.filter(t=>t.url===saved.usedPowerBIResolvedURL||t.url.includes('/reports/458f40a9-2b3f-4518-a3cb-d699fef65baa/'));if(matches.length===1)tab=matches[0];}
 if(!tab)tab=await chrome.tabs.create({url:USED_POWERBI_REPORT_URL,active:false});
 await chrome.storage.session.set({usedPowerBITab:tab.id});await ToolboxTabGroup.add(tab);return tab;
}
async function readUsedPowerBI(kind,payload={}){
 if(kind==='usedPowerBIInit'){
  const data=await ensureUsedCatalogue(),saved=await chrome.storage.local.get('toolboxUsedPowerBIStatus');
  if(!usedPowerBIBusy&&saved.toolboxUsedPowerBIStatus?.state==='loading')await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'error',message:'Lecture interrompue. Les données précédentes sont conservées; tu peux relancer les quantités.'}});
  return {count:data.rows.length};
 }
 if(usedPowerBIBusy)throw Error('Une lecture Power BI est déjà en cours.');usedPowerBIBusy=true;usedPowerBIStop=false;
 let tab,stage='Vérification des autorisations',diagnostics=[],frameWarning='';
 try{
  if(['usedPowerBIRead','usedPowerBIReadForce','usedCatalogueImport','usedCatalogueReset'].includes(kind)){
   stage='Chargement du catalogue enregistré';
   const base=await ensureUsedCatalogue();
   if(kind==='usedCatalogueReset'){
    const data=await initialUsedCatalogue();await chrome.storage.local.set({toolboxUsedPowerBI:data,toolboxUsedPowerBIStatus:{state:'done',message:'Catalogue Excel initial rétabli.'}});return {count:data.rows.length};
   }
   if(kind==='usedCatalogueImport'){
    stage='Import Excel';await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'loading',message:'Mise à jour du catalogue depuis Excel…'}});
    if(!['quantities','catalogue'].includes(payload.mode))throw Error('Mode d’import invalide.');
    const result=ToolboxUsedCatalogue.merge(base,payload.data,{source:'Excel',mode:payload.mode});
    await chrome.storage.local.set({toolboxUsedPowerBI:result,toolboxUsedPowerBIStatus:{state:'done',message:'Import Excel terminé. Le catalogue est conservé.'}});return {count:result.rows.length,stats:result.lastImportStats};
   }
   if(kind==='usedPowerBIRead'&&base.dailyDate===ToolboxUsedCatalogue.day(Date.now())&&(!base.lastImport?base.complete:base.lastImport.complete||base.lastImport.loadedToEnd)){
    await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'cached',message:'Quantités déjà récupérées aujourd’hui. Importe un nouvel Excel ou utilise Forcer la lecture Power BI dans les options.'}});return {count:base.rows.length,cached:true};
   }
  }
  if(!await chrome.permissions.contains({origins:['https://app.powerbi.com/*']}))throw Error('Autorise les accès au Toolbox avant de lire Power BI.');
  if(kind==='usedPowerBIBind'){
   stage='Association de l’onglet actif';
   const [active]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
   if(!isUsedPowerBI(active)||/singleSignOn|signin|login/i.test(active.url))throw Error('Affiche le rapport Used Gear dans l’onglet actif, puis réessaie.');
   await chrome.storage.session.set({usedPowerBITab:active.id,usedPowerBIResolvedURL:active.url});await ToolboxTabGroup.add(active);return {tabId:active.id};
  }
  stage='Ouverture ou récupération de l’onglet';tab=await usedPowerBITab();
  if(kind==='usedPowerBIOpen'){const opened=await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(opened.windowId,{focused:true});return {tabId:tab.id};}
  if(kind==='usedPowerBIRead'||kind==='usedPowerBIReadForce')await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'loading',tabId:tab.id}});
  stage='Chargement du rapport';
  const deadline=Date.now()+20000;let loaded=false;
  while(Date.now()<deadline){tab=await chrome.tabs.get(tab.id);if(tab.status==='complete'){loaded=true;break;}await new Promise(r=>setTimeout(r,400));}
  if(!loaded)throw Error('Le rapport charge encore. Ouvre Power BI puis réessaie.');
  if(!isUsedPowerBI(tab)||/singleSignOn|signin|login/i.test(tab.url))throw Error('Connecte-toi à Power BI dans l’onglet du rapport, puis clique sur Actualiser.');
  async function inspect(target,label){
   stage='Accès au contenu · '+label;
   await chrome.scripting.executeScript({target,files:['used-powerbi-reader.js']});
   stage='Lecture du tableau · '+label;
   return chrome.scripting.executeScript({target,func:async diagnostic=>{try{if(diagnostic)return {diagnostic:globalThis.ToolboxUsedPowerBIReader.diagnostic()};await globalThis.ToolboxUsedPowerBIReader.ensureReady();return await globalThis.ToolboxUsedPowerBIReader.read();}catch(e){return {error:e.message,diagnostic:globalThis.ToolboxUsedPowerBIReader.diagnostic()};}},args:[kind==='usedPowerBIDiagnostic']});
  }
  // A sandboxed child frame must not block extraction from the main report page.
  let frames=await inspect({tabId:tab.id},'page principale');
  const topRecognized=frames.some(f=>f.result?.more||f.result?.rows?.length||f.result?.diagnostic?.tables?.length);
  if(!topRecognized){
   try{frames=await inspect({tabId:tab.id,allFrames:true},'sous-fenêtres');}
   catch(e){frameWarning=stage+' : '+e.message;}
  }
  diagnostics=frames.map(f=>({frameId:f.frameId,...f.result?.diagnostic}));
  if(kind==='usedPowerBIDiagnostic')return {diagnostics,frameWarning,tabId:tab.id};
  const results=frames.filter(f=>f.result?.more||f.result?.rows?.length);
  stage='Identification des résultats';
  if(results.length!==1)throw Error(results.length?'Plusieurs tableaux lisibles détectés. Utilise Diagnostic Power BI.':frames.find(f=>f.result?.diagnostic?.tables?.length)?.result.error||frames.find(f=>f.frameId===0)?.result?.error||(frameWarning?'La page principale est accessible, mais une sous-fenêtre refuse la lecture. Utilise Diagnostic Power BI.':'Tableau non détecté. Ouvre LP Catalog - Used Gear, puis utilise Diagnostic Power BI.'));
  let value=results[0].result;
  const target={tabId:tab.id,frameIds:[results[0].frameId]};
  while(value.more){
   if(usedPowerBIStop){await chrome.scripting.executeScript({target,func:()=>globalThis.ToolboxUsedPowerBIReader.cancel()});throw Error('Chargement arrêté. Le catalogue complet n’a pas été chargé; les données précédentes sont conservées.');}
   stage='Chargement complet du catalogue';
   await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'loading',tabId:tab.id,count:value.count,message:value.count+' lignes récupérées · chargement en cours…'}});
   const [chunk]=await chrome.scripting.executeScript({target,func:async()=>{try{return await globalThis.ToolboxUsedPowerBIReader.next();}catch(e){return {error:e.message};}}});
   if(chunk?.result?.error)throw Error(chunk.result.error);
   if(!chunk?.result)throw Error('Le rapport ne répond plus. Le chargement complet n’est pas confirmé.');
   value=chunk.result;
  }
  if(usedPowerBIStop)throw Error('Chargement arrêté. Les données précédentes sont conservées.');
  await chrome.storage.session.set({usedPowerBIResolvedURL:tab.url});
  stage='Mise à jour des quantités';
  const base=await ensureUsedCatalogue(),result={...ToolboxUsedCatalogue.merge(base,value,{source:'Power BI'}),tabId:tab.id,lastPowerBIReadAt:Date.now()};
  await chrome.storage.local.set({toolboxUsedPowerBI:result,toolboxUsedPowerBIStatus:{state:'done',tabId:tab.id,message:'Quantités mises à jour. Les prix et NBV du catalogue sont conservés.'}});return {count:result.rows.length,stats:result.lastImportStats};
 }catch(e){
  const raw=String(e.message||e),blocked=/blocked|cannot access|not allowed|denied/i.test(raw);
  const message=stage+' : '+raw+(blocked?' · Le navigateur refuse cette opération. Vérifie l’accès de l’extension à app.powerbi.com; si une politique de ton organisation le bloque, elle devra être autorisée par les TI.':'');
  const detail={stage,error:raw,diagnostics,frameWarning,tabId:tab?.id};
  if(kind!=='usedPowerBIOpen')await chrome.storage.local.set({toolboxUsedPowerBIStatus:{state:'error',message,tabId:tab?.id},toolboxUsedPowerBIDiagnostic:detail});
  if(kind==='usedPowerBIDiagnostic')return detail;
  throw Error(message);
 }finally{usedPowerBIBusy=false;}
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(s.id!==chrome.runtime.id)return;if(m?.kind==='usedPowerBIStop'){usedPowerBIStop=true;reply({value:{stopping:true}});return;}if(!['usedPowerBIInit','usedPowerBIRead','usedPowerBIReadForce','usedPowerBIOpen','usedPowerBIDiagnostic','usedPowerBIBind','usedCatalogueImport','usedCatalogueReset'].includes(m?.kind))return;readUsedPowerBI(m.kind,m).then(value=>reply({value}),e=>reply({error:e.message}));return true;});
