// One work group per browser window; grouping never aborts a CRM operation.
(()=>{
 const title='Solotech Toolbox';let queue=Promise.resolve();
 async function groupFor(windowId){
  const saved=(await chrome.storage.session.get('toolboxTabGroups')).toolboxTabGroups||{};
  let group;
  if(Number.isInteger(saved[windowId]))try{const g=await chrome.tabGroups.get(saved[windowId]);if(g.windowId===windowId)group=g;}catch{}
  if(!group)group=(await chrome.tabGroups.query({windowId,title}))[0];
  return {group,saved};
 }
 async function addNow(tab){
  if(!chrome.tabs.group||!chrome.tabGroups||tab.pinned)return;
  const current=await chrome.tabs.get(tab.id),{group,saved}=await groupFor(current.windowId);
  const groupId=await chrome.tabs.group({tabIds:[current.id],...(group?{groupId:group.id}:{createProperties:{windowId:current.windowId}})});
  saved[current.windowId]=groupId;
  await chrome.storage.session.set({toolboxTabGroups:saved});
  const active=(await chrome.tabs.query({groupId,active:true})).length>0;
  await chrome.tabGroups.update(groupId,{title,color:'purple',collapsed:!active});
  await chrome.storage.local.remove('toolboxTabGroupWarning');
 }
 async function add(tab){
  const job=queue.then(()=>addNow(tab));queue=job.catch(()=>{});
  try{await job;}catch(e){await chrome.storage.local.set({toolboxTabGroupWarning:String(e.message||e)}).catch(()=>{});}
  return tab;
 }
 chrome.tabs.onActivated.addListener(info=>{
  const job=queue.then(async()=>{
   if(!chrome.tabGroups)return;
   const {group}=await groupFor(info.windowId);if(!group)return;
   const tab=await chrome.tabs.get(info.tabId);
   await chrome.tabGroups.update(group.id,{collapsed:tab.groupId!==group.id});
  });queue=job.catch(()=>{});
 });
 globalThis.ToolboxTabGroup={add};
})();
