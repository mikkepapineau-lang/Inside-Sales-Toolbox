// Small interaction transitions. Functional state always updates immediately.
(()=>{
 const active=new WeakMap(),disclosures=new WeakMap();
 const reduced=()=>globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches===true;
 function animate(element,frames,options){
  if(!element?.animate||reduced())return;
  active.get(element)?.cancel();
  const animation=element.animate(frames,{duration:160,easing:'cubic-bezier(.2,.7,.2,1)',...options});active.set(element,animation);
  animation.finished.then(()=>{if(active.get(element)===animation)active.delete(element);},()=>{});return animation;
 }
 function enter(element){return animate(element,[{opacity:.35,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:190});}
 function results(element){return animate(element,[{opacity:.55},{opacity:1}],{duration:120});}
 function toggle(details){
  const previous=disclosures.get(details),opening=previous?!previous.opening:!details.open;
  const start=details.getBoundingClientRect().height,original=previous?.original||{height:details.style.height,overflow:details.style.overflow};
  previous?.animation.cancel();details.style.height='';details.style.overflow='';details.open=true;
  const css=getComputedStyle(details),summary=details.querySelector('summary');
  const collapsed=summary.getBoundingClientRect().height+['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((n,k)=>n+(parseFloat(css[k])||0),0);
  const end=opening?details.getBoundingClientRect().height:collapsed;
  if(!details.animate){details.open=opening;return;}
  details.style.overflow='hidden';
  const animation=details.animate([{height:start+'px'},{height:end+'px'}],{duration:180,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'}),entry={animation,opening,original};disclosures.set(details,entry);
  animation.finished.then(()=>{
   if(disclosures.get(details)!==entry)return;
   details.open=opening;details.style.height=original.height;details.style.overflow=original.overflow;animation.cancel();disclosures.delete(details);
  },()=>{});
 }
 document.addEventListener('click',event=>{
  if(event.defaultPrevented||reduced())return;
  const summary=event.target.closest?.('summary'),details=summary?.parentElement;
  if(!details||details.tagName!=='DETAILS'||details.classList.contains('used-facet')||event.target.closest('a,button,input,select,textarea'))return;
  if(!details.animate)return;event.preventDefault();toggle(details);
 });
 document.addEventListener('toggle',event=>{
  const details=event.target;
  if(details?.open&&details.classList?.contains('used-facet')){
   const popover=details.querySelector('.facet-popover');
   animate(popover,[{opacity:0,transform:'translateY('+((details.dataset.direction==='up')?4:-4)+'px)'},{opacity:1,transform:'translateY(0)'}],{duration:140});
  }
 },true);
 globalThis.ToolboxMotion={enter,results};
})();
