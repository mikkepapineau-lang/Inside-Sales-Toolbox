(()=>{
 const el=id=>document.getElementById(id);let data=null,status={},visibleLimit=80,importing=false,indexedData=null,filterIndex=null,filterSaveTimer,filtersTouched=false;
 const filterUI=ToolboxUsedFilters.mount(changeFilters);
 const {node,row:recordRow,fieldList,diagnostics,time,link}=ToolboxList;
 const numeric=ToolboxUsedCatalogue.number;
 const dateOnly=s=>new Date(s+'T12:00:00Z').toLocaleDateString(document.documentElement.lang==='en-CA'?'en-CA':'fr-CA',{year:'numeric',month:'short',day:'numeric'});
 function money(value){const n=numeric(value);return n===null?value:new Intl.NumberFormat(document.documentElement.lang==='en-CA'?'en-CA':'fr-CA',{minimumFractionDigits:2,maximumFractionDigits:2}).format(n);}
 function render(){
  const root=el('used-results');root.replaceChildren();const loading=status.state==='loading'||importing;
  for(const id of ['used-refresh','used-import','used-force','used-clear','used-import-mode'])el(id).disabled=loading;
  el('used-status').textContent=importing?'Lecture du fichier Excel…':status.message||(loading?'Lecture de l’inventaire usagé…':data?'':'Chargement du catalogue Excel…');
  el('used-stop').hidden=!loading||importing;el('used-more').hidden=true;
  el('used-time').textContent=data?(data.lastQuantityAt?'Quantités récupérées · '+time(data.lastQuantityAt):data.sourceDate?'Quantités · Excel du '+dateOnly(data.sourceDate):time(data.at)):'';
  el('used-status').dataset.state=status.state||'idle';el('used-status').hidden=!!data&&!loading&&!status.message;
  if(!data){el('used-count').textContent='';el('used-currency').textContent='';el('used-coverage').textContent='';return;}
  const headers=data.headers.map(ToolboxUsedCatalogue.column),index=key=>headers.indexOf(key);
  const cols={item:index('d365itemid'),sku:index('sku'),description:index('description'),brand:index('manufacturer'),available:index('qtyavailable'),owned:index('qtyowned'),sellable:index('maxqtytosell'),price:index('sellprice'),nbv:index('nbv')};
  const get=(r,key)=>String(cols[key]>=0?r.values[cols[key]]??'':'');
  if(data!==indexedData){indexedData=data;filterIndex=ToolboxUsedFilterModel.build(data);}
  const filtered=ToolboxUsedFilterModel.evaluate(filterIndex,filterUI.state),records=filtered.records;
  filterUI.render(filtered,filterIndex.availableFields);
  const groups=new Map();records.forEach(x=>{if(!groups.has(x.key))groups.set(x.key,[]);groups.get(x.key).push(x.r);});
  el('used-count').textContent=groups.size+' article(s) · '+records.length+' / '+data.rows.length+' ligne(s)';
  el('used-currency').textContent=data.currency||'Devise à vérifier';
  const stats=data.lastImportStats;
  el('used-coverage').textContent=stats?stats.updated+' mis à jour · '+stats.added+' nouveaux · '+stats.retained+' conservés sans nouvelle quantité'+(stats.ambiguous?' · '+stats.ambiguous+' correspondances ambiguës ignorées':''):'Catalogue Excel · '+data.rows.length+' lignes';
  if(data.lastImport?.source==='Power BI'&&!data.lastImport.complete)el('used-coverage').textContent+=' · total Power BI non confirmé';
  el('used-source').textContent=data.filters||'';el('used-update-source').textContent=data.lastImport?.filters||'';
  el('used-financial-time').textContent=data.catalogueAt?'Dernier import prix et NBV · '+time(data.catalogueAt):data.sourceDate?'Prix et NBV · Excel du '+dateOnly(data.sourceDate):'Prix et NBV du catalogue enregistré';
  el('used-more').hidden=groups.size<=visibleLimit;
  for(const [groupKey,rows] of [...groups.entries()].slice(0,visibleLimit)){
   const r=rows[0],meta=[];
   if(rows.length===1){for(const [key,label] of [['available','Dispo.'],['owned','Possédé'],['sellable','Max.']])if(get(r,key)!=='')meta.push({label,value:get(r,key),positive:key==='available'&&numeric(get(r,key))>0});}
   else meta.push({value:rows.length+' lignes source',raw:false});
   if(rows.some(r=>r.qtyBatch&&r.qtyBatch!==data.quantityBatch))meta.push({value:'Quantités non revérifiées',raw:false});
   else if(rows.some(r=>r.qtyPartial))meta.push({value:'Quantités partielles',raw:false});
   const amounts=[['price','Vente'],['nbv','NBV']].map(([key,label])=>{const values=[...new Set(rows.map(r=>get(r,key)))],raw=values.length===1&&values[0]!=='';return {label,raw,value:raw?money(values[0]):values.length>1?'Plusieurs valeurs':'Non renseigné'};});
   const name=[get(r,'brand'),get(r,'item')?'D365 '+get(r,'item'):''].filter(Boolean).join(' · ');
   const record=recordRow({key:'used:'+groupKey,code:get(r,'sku')||get(r,'item'),name,description:get(r,'description'),amounts,meta});
   rows.forEach((r,i)=>{
    if(rows.length>1)record.append(node('h4','record-source-heading','Ligne source '+(i+1)));
    if(r.qtyAt)record.append(node('p','quantity-provenance','Quantités récupérées · '+time(r.qtyAt)+' · '+(r.qtySource||'')));
    if(r.financialAt||data.sourceDate)record.append(node('p','quantity-provenance','Prix et NBV · '+(r.financialAt?time(r.financialAt):'Excel du '+dateOnly(data.sourceDate))));
    record.append(fieldList(data.headers,r.values));if(r.href)record.append(link('Ouvrir le lien SKU ↗',r.href,'record-source-link'));
   });root.append(record);
  }
  if(!records.length)root.append(node('p','muted','Aucun article ne correspond aux filtres locaux.'));
 }
 function changeFilters(results=true,debounce=false){
  filtersTouched=true;filterUI.state.query=el('used-query').value;filterUI.state.availableOnly=el('used-available').checked;
  if(results){visibleLimit=80;render();globalThis.ToolboxMotion?.results(el('used-results'));}
  clearTimeout(filterSaveTimer);const snapshot=filterUI.serialize();
  const save=()=>chrome.storage.local.set({toolboxUsedFilters:snapshot}).catch(()=>{});
  if(debounce)filterSaveTimer=setTimeout(save,150);else save();
 }
 async function action(kind,payload={}){
  try{const r=await chrome.runtime.sendMessage({kind,...payload});if(r?.error)throw Error(r.error);if(kind==='usedPowerBIDiagnostic')diagnostics('used-diagnostic-output',r.value);if(kind==='usedPowerBIBind'){status={state:'done',message:'Onglet associé. Clique sur Actualiser.'};render();}return r?.value;}
  catch(e){status={state:'error',message:e.message};render();}
 }
 el('used-refresh').onclick=()=>action('usedPowerBIRead');el('used-force').onclick=()=>action('usedPowerBIReadForce');el('used-open').onclick=()=>action('usedPowerBIOpen');el('used-bind').onclick=()=>action('usedPowerBIBind');el('used-diagnostic').onclick=()=>action('usedPowerBIDiagnostic');
 el('used-query').oninput=()=>changeFilters(true,true);el('used-available').onchange=()=>changeFilters();el('used-more').onclick=()=>{visibleLimit+=80;render();};el('used-stop').onclick=()=>action('usedPowerBIStop');el('used-clear').onclick=()=>action('usedCatalogueReset');
 el('used-import').onclick=()=>el('used-file').click();
 el('used-file').onchange=async()=>{
  const file=el('used-file').files?.[0];if(!file)return;const mode=el('used-import-mode').value;importing=true;render();
  try{const parsed=await ToolboxUsedExcel.read(file);await action('usedCatalogueImport',{data:parsed,mode});}
  catch(e){status={state:'error',message:e.message};}
  finally{importing=false;el('used-file').value='';render();}
 };
 chrome.storage.onChanged.addListener((c,area)=>{if(area!=='local')return;let changed=false;if(c.toolboxUsedPowerBI){data=c.toolboxUsedPowerBI.newValue;changed=true;}if(c.toolboxUsedPowerBIStatus){status=c.toolboxUsedPowerBIStatus.newValue||{};changed=true;}if(c.toolboxUsedFilters){filtersTouched=true;const saved=ToolboxUsedFilterModel.serialize(ToolboxUsedFilterModel.state(c.toolboxUsedFilters.newValue));if(JSON.stringify(saved)!==JSON.stringify(filterUI.serialize())){clearTimeout(filterSaveTimer);filterUI.restore(saved);visibleLimit=80;changed=true;}}if(c.toolboxUsedPowerBIDiagnostic)diagnostics('used-diagnostic-output',c.toolboxUsedPowerBIDiagnostic.newValue);if(changed)render();});
 chrome.storage.local.get(['toolboxUsedPowerBI','toolboxUsedPowerBIStatus','toolboxUsedFilters']).then(async s=>{data=s.toolboxUsedPowerBI;status=s.toolboxUsedPowerBIStatus||{};if(!filtersTouched)filterUI.restore(s.toolboxUsedFilters);render();await action('usedPowerBIInit');});
})();
