(function(root){
const names=['ASIA - OTHERS','BIRMINGHAM','CALGARY','DEKALB','EUROPE - OTHERS','FRANCE','GERMANY','HALIFAX','LAS VEGAS','LATIN AMERICA','LONDON','LOS ANGELES','MANCHESTER','MIAMI','MIDDLE EAST','MONTREAL','NASHVILLE','ORLANDO','OTTAWA','PENSACOLA','QUEBEC','SAGUENAY','SOUTHAMPTON','TORONTO','UNITED KINGDOM'];
const cities=[['CALGARY',51.045,-114.057,'CA'],['HALIFAX',44.649,-63.575,'CA'],['MONTREAL',45.502,-73.567,'CA'],['OTTAWA',45.421,-75.697,'CA'],['QUEBEC',46.814,-71.208,'CA'],['SAGUENAY',48.428,-71.066,'CA'],['TORONTO',43.653,-79.383,'CA'],['DEKALB',41.93,-88.75,'US'],['LAS VEGAS',36.17,-115.14,'US'],['LOS ANGELES',34.05,-118.24,'US'],['MIAMI',25.76,-80.19,'US'],['NASHVILLE',36.16,-86.78,'US'],['ORLANDO',28.54,-81.38,'US'],['PENSACOLA',30.42,-87.22,'US'],['BIRMINGHAM',52.486,-1.89,'GB'],['LONDON',51.507,-0.128,'GB'],['MANCHESTER',53.481,-2.243,'GB'],['SOUTHAMPTON',50.91,-1.404,'GB']];
const warehouses={MONTREAL:'YUL-01',QUEBEC:'QUE-01',TORONTO:'TOR-01',OTTAWA:'OTT-01'};
function distance(a,b){const r=Math.PI/180;const x=Math.sin((b[0]-a[0])*r/2)**2+Math.cos(a[0]*r)*Math.cos(b[0]*r)*Math.sin((b[1]-a[1])*r/2)**2;return 6371*2*Math.asin(Math.sqrt(Math.min(1,x)));}
function nearest(lat,lon,country){if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return '';const c=(country||'').toUpperCase();if(c==='FR')return 'FRANCE';if(c==='DE')return 'GERMANY';let pool=cities.filter(x=>['CA','US'].includes(c)?['CA','US'].includes(x[3]):['GB','UK'].includes(c)?x[3]==='GB':false);if(pool.length)return pool.sort((a,b)=>distance([lat,lon],a.slice(1,3))-distance([lat,lon],b.slice(1,3)))[0][0];
for(const [territory,list] of [['EUROPE - OTHERS','AL AD AT BE BA BG HR CY CZ DK EE FI GR HU IS IE IT LV LI LT LU MT MD MC ME NL MK NO PL PT RO SM RS SK SI ES SE CH UA VA'],['MIDDLE EAST','AE BH EG IR IQ IL JO KW LB OM PS QA SA SY TR YE'],['LATIN AMERICA','MX AR BO BR CL CO CR CU DO EC SV GT HN NI PA PY PE UY VE BZ GY SR HT'],['ASIA - OTHERS','AF BD BT BN KH CN IN ID JP KZ KG LA MY MV MN MM NP KP PK PH SG KR LK TW TJ TH TL TM UZ VN']])if(list.split(' ').includes(c))return territory;return '';}
function officeFor(territory){return ['QUEBEC','SAGUENAY'].includes(territory)?'QUEBEC':['TORONTO','OTTAWA'].includes(territory)?territory:'MONTREAL';}
function infer(data){
 const city=(data.city||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().trim();
 const aliases={'QUEBEC CITY':'QUEBEC','VILLE DE QUEBEC':'QUEBEC','QUÉBEC':'QUEBEC'};
 const match=cities.find(c=>c[0]===(aliases[city]||city));
 let digits=(data.phone||'').replace(/\D/g,'');if(digits.length===11&&digits[0]==='1')digits=digits.slice(1);
 const codes={514:'MONTREAL',438:'MONTREAL',263:'MONTREAL',450:'MONTREAL',579:'MONTREAL',354:'MONTREAL',418:'QUEBEC',581:'QUEBEC',367:'QUEBEC',416:'TORONTO',437:'TORONTO',647:'TORONTO',942:'TORONTO',905:'TORONTO',289:'TORONTO',365:'TORONTO',742:'TORONTO',613:'OTTAWA',343:'OTTAWA',753:'OTTAWA'};
 const territory=match?.[0]||(digits.length===10?codes[digits.slice(0,3)]:null)||'MONTREAL';const office=officeFor(territory);
 return {territory,office,warehouse:warehouses[office],exactCity:!!match};
}
root.Territories={names,cities,warehouses,nearest,distance,infer,officeFor};if(typeof module!=='undefined')module.exports=root.Territories;
})(globalThis);
