(()=>{
 const el=id=>document.getElementById(id);let data=null,status={},filter='';
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 function render(){
  const root=el('powerbi-results');root.replaceChildren();el('powerbi-refresh').disabled=status.state==='loading';
  el('powerbi-status').textContent=status.state==='loading'?'Lecture du rapport Power BI…':status.state==='error'?status.message:data?'Lecture terminée.':'Ouvre Ready to PIK et choisis tes filtres dans Power BI, puis clique sur Actualiser.';
  if(!data)return;
  el('powerbi-freshness').textContent=new Date(data.at).toLocaleString(document.documentElement.lang==='en'?'en-CA':'fr-CA');
  const keys=data.headers.map(h=>norm(h).replace(/[^a-z0-9]/g,''));
  const find=rx=>keys.findIndex(v=>rx.test(v));
  const col={order:find(/^(salesordernumber|sonumber|numerodecommande|numerocommande)$/),customer:find(/^(customer|client)$/),amount:find(/^(totalnotinvoiced|totalnonfacture)$/),qty:find(/^(physicalreserveqty|quantitereserveephysiquement)$/),delivery:find(/^(modeofdelivery|modedelivraison)$/),payment:find(/^(payment|paiement)$/),status:find(/^status$/),rep:find(/^(salesrepname|representant)$/),ref:find(/^customerreference$/),po:find(/^customerrequisition$/),project:find(/^projectid$/)};
  const val=(r,k)=>col[k]>=0?r.values[col[k]]||'':'';
  const rep=el('powerbi-rep').value,query=norm(filter);
  const list=data.rows.filter(r=>(!rep||val(r,'rep')===rep)&&(!query||norm(r.values.join(' ')).includes(query)));
  el('powerbi-count').textContent=list.length+' / '+data.rows.length;
  for(const r of list){
   const card=node('article','product-card powerbi-card'),head=node('div','product-card-heading');
   let order=node('strong','product-sku',val(r,'order'));if(r.href){try{const u=new URL(r.href);if(u.protocol==='https:'&&u.hostname==='solotech.operations.dynamics.com'){order=node('a','product-sku',val(r,'order'));order.href=u.href;order.target='_blank';order.rel='noopener noreferrer';}}catch{}}
   head.append(order);card.append(head,node('h3','powerbi-customer',val(r,'customer')));
   const dl=node('dl','product-metrics product-warehouse-metrics');
   for(const [key,label] of [['amount','Non facturé'],['qty','Quantité réservée'],['delivery','Livraison'],['payment','Paiement'],['status','Statut']])if(val(r,key)){const box=node('div','');box.append(node('dt','',label),node('dd','',val(r,key)));dl.append(box);}card.append(dl);
   for(const [key,label] of [['ref','Référence client'],['po','Bon de commande'],['project','Projet'],['rep','Représentant']])if(val(r,key))card.append(node('p','product-meta',label+' : '+val(r,key)));
   const detail=node('details','product-details');detail.append(node('summary','','Toutes les informations'));const fields=node('dl','product-all-values');data.headers.forEach((h,i)=>{if(r.values[i]){const pair=node('div','');pair.append(node('dt','',h),node('dd','',r.values[i]));fields.append(pair);}});detail.append(fields);card.append(detail);root.append(card);
  }
  if(!list.length)root.append(node('p','muted','Aucune fiche ne correspond aux filtres locaux.'));
 }
 function reps(){const selected=el('powerbi-rep').value;el('powerbi-rep').replaceChildren(node('option','','Tous les représentants'));el('powerbi-rep').firstChild.value='';if(data){const i=data.headers.findIndex(h=>norm(h).replace(/[^a-z0-9]/g,'')==='salesrepname');for(const v of [...new Set(data.rows.map(r=>r.values[i]).filter(Boolean))].sort()){const o=node('option','',v);o.value=v;el('powerbi-rep').append(o);}}el('powerbi-rep').value=selected;}
 async function action(kind){try{const r=await chrome.runtime.sendMessage({kind});if(r?.error)throw Error(r.error);if(kind==='powerBIDiagnostic'){el('powerbi-diagnostic-output').hidden=false;el('powerbi-diagnostic-output').value=JSON.stringify(r.value,null,2);}if(kind==='powerBIBind')el('powerbi-status').textContent='Onglet associé. Clique sur Actualiser.';}catch(e){el('powerbi-status').textContent=e.message;}}
 el('powerbi-refresh').onclick=()=>action('powerBIRead');el('powerbi-open').onclick=()=>action('powerBIOpen');el('powerbi-diagnostic').onclick=()=>action('powerBIDiagnostic');
 el('powerbi-bind').onclick=()=>action('powerBIBind');
 el('powerbi-query').oninput=()=>{filter=el('powerbi-query').value;render();};el('powerbi-rep').onchange=()=>{chrome.storage.local.set({toolboxPowerBIRep:el('powerbi-rep').value});render();};
 el('powerbi-clear').onclick=async()=>{await chrome.storage.local.remove('toolboxPowerBI');data=null;el('powerbi-freshness').textContent='';el('powerbi-count').textContent='';reps();render();};
 chrome.storage.onChanged.addListener((c,area)=>{if(area!=='local')return;if(c.toolboxPowerBI){data=c.toolboxPowerBI.newValue;reps();}if(c.toolboxPowerBIStatus)status=c.toolboxPowerBIStatus.newValue||{};render();});
 chrome.storage.local.get(['toolboxPowerBI','toolboxPowerBIStatus','toolboxPowerBIRep']).then(s=>{data=s.toolboxPowerBI;status=s.toolboxPowerBIStatus||{};reps();el('powerbi-rep').value=s.toolboxPowerBIRep||'';render();});
})();
