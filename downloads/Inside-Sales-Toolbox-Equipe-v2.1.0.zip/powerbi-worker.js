const POWERBI_REPORT_URL='https://app.powerbi.com/links/lNdArEWzXE?ctid=c2f120b6-e8fc-402c-9972-fa891cb53927&pbi_source=linkShare&bookmarkGuid=ff596301-8009-4b69-be11-40ae01525ce3';
let powerBIBusy=false;
const isPowerBI=tab=>{try{return new URL(tab.url).origin==='https://app.powerbi.com';}catch{return false;}};
async function powerBITab(){
 const saved=await chrome.storage.session.get(['powerBITab','powerBIResolvedURL']);
 let tab;try{if(saved.powerBITab)tab=await chrome.tabs.get(saved.powerBITab);}catch{}
 if(!isPowerBI(tab))tab=null;
 if(!tab){const tabs=await chrome.tabs.query({url:'https://app.powerbi.com/*'});const matches=tabs.filter(t=>t.url===saved.powerBIResolvedURL||t.url.includes('/links/lNdArEWzXE'));if(matches.length===1)tab=matches[0];}
 if(!tab)tab=await chrome.tabs.create({url:POWERBI_REPORT_URL,active:false});
 await chrome.storage.session.set({powerBITab:tab.id});return tab;
}
async function readPowerBI(kind){
 if(powerBIBusy)throw Error('Une lecture Power BI est déjà en cours.');powerBIBusy=true;
 let tab;
 try{
  if(!await chrome.permissions.contains({origins:['https://app.powerbi.com/*']}))throw Error('Autorise les accès au Toolbox avant de lire Power BI.');
  if(kind==='powerBIBind'){
   const [active]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
   if(!isPowerBI(active)||/singleSignOn|signin|login/i.test(active.url))throw Error('Affiche le rapport Power BI dans l’onglet actif, puis réessaie.');
   await chrome.storage.session.set({powerBITab:active.id,powerBIResolvedURL:active.url});return {tabId:active.id};
  }
  tab=await powerBITab();
  if(kind==='powerBIOpen'){const opened=await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(opened.windowId,{focused:true});return {tabId:tab.id};}
  if(kind==='powerBIRead')await chrome.storage.local.set({toolboxPowerBIStatus:{state:'loading',tabId:tab.id}});
  const deadline=Date.now()+20000;let loaded=false;
  while(Date.now()<deadline){tab=await chrome.tabs.get(tab.id);if(tab.status==='complete'){loaded=true;break;}await new Promise(r=>setTimeout(r,400));}
  if(!loaded)throw Error('Le rapport charge encore. Ouvre Power BI puis réessaie.');
  if(!isPowerBI(tab)||/singleSignOn|signin|login/i.test(tab.url))throw Error('Connecte-toi à Power BI dans l’onglet du rapport, puis clique sur Actualiser.');
  await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},files:['powerbi-reader.js']});
  const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:async diagnostic=>{try{return diagnostic?{diagnostic:globalThis.ToolboxPowerBIReader.diagnostic()}:await globalThis.ToolboxPowerBIReader.read();}catch(e){return {error:e.message};}},args:[kind==='powerBIDiagnostic']});
  const diagnostics=frames.map(f=>({frameId:f.frameId,...f.result?.diagnostic}));
  if(kind==='powerBIDiagnostic')return {diagnostics,tabId:tab.id};
  const results=frames.filter(f=>f.result?.rows?.length);
  if(results.length!==1)throw Error(results.length?'Plusieurs tableaux lisibles détectés. Utilise Diagnostic Power BI.':frames.find(f=>f.result?.diagnostic?.tables?.length)?.result.error||'Tableau non détecté. Ouvre Ready to PIK, puis utilise Diagnostic Power BI.');
  await chrome.storage.session.set({powerBIResolvedURL:tab.url});
  const result={...results[0].result,tabId:tab.id,at:Date.now()};
  await chrome.storage.local.set({toolboxPowerBI:result,toolboxPowerBIStatus:{state:'done',tabId:tab.id}});return {count:result.rows.length};
 }catch(e){if(kind!=='powerBIOpen')await chrome.storage.local.set({toolboxPowerBIStatus:{state:'error',message:e.message,tabId:tab?.id}});throw e;}finally{powerBIBusy=false;}
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(s.id!==chrome.runtime.id||!['powerBIRead','powerBIOpen','powerBIDiagnostic','powerBIBind'].includes(m?.kind))return;readPowerBI(m.kind).then(value=>reply({value}),e=>reply({error:e.message}));return true;});
