const PRODUCT_SEARCH_URL='https://solotech.operations.dynamics.com/?cmp=CAOP&mi=SOLMCRProductQuickQuote';
let productSearchBusy=false;
async function searchProduct(selection){
 const text=String(selection||'').trim();
 if(!text||text.length>500)throw Error('Sélectionne un SKU ou un texte de recherche de 500 caractères maximum.');
 if(productSearchBusy)throw Error('Une recherche Product Search est déjà en cours.');
 productSearchBusy=true;
 try{
 if(!await chrome.permissions.contains({origins:['https://solotech.operations.dynamics.com/*']}))throw Error('Autorise D365 avec « Autoriser tous les accès », puis relance le clic droit.');
 // Reuse only the dedicated Product Search tab; never navigate away from a quotation or prospect.
 const saved=await chrome.storage.session.get('productSearchTab');let tab;
 if(saved.productSearchTab){try{const t=await chrome.tabs.get(saved.productSearchTab);const u=new URL(t.url);if(u.origin==='https://solotech.operations.dynamics.com'&&u.searchParams.get('cmp')==='CAOP'&&u.searchParams.get('mi')==='SOLMCRProductQuickQuote')tab=await chrome.tabs.update(t.id,{active:true});}catch{}}
 if(!tab)tab=await chrome.tabs.create({url:PRODUCT_SEARCH_URL,active:true});
 await chrome.storage.session.set({productSearchTab:tab.id});
 await chrome.windows.update(tab.windowId,{focused:true});
 const deadline=Date.now()+45000;let ready=false;
 while(Date.now()<deadline){
 const current=await chrome.tabs.get(tab.id);
 if(current.status==='complete'){
 const u=new URL(current.url);
 if(u.origin==='https://solotech.operations.dynamics.com'&&u.searchParams.get('cmp')==='CAOP'&&u.searchParams.get('mi')==='SOLMCRProductQuickQuote'){
 await chrome.scripting.executeScript({target:{tabId:tab.id},files:['d365-controls.js']});
 const [r]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:async value=>{
  const field=globalThis.D365Controls.find('SOLMCRProductQuickQuote','MCRSearchString','field');
  if(!field)return {ready:false};
  field.focus();const proto=field.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(field,value);
  field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));
  await new Promise(r=>setTimeout(r,250));
  const target=globalThis.D365Controls.find('SOLMCRProductQuickQuote','MCRSearchString','field');
  if(!target||target.value!==value)throw Error('Le texte de recherche n’a pas été retenu.');
  target.focus();
  for(const type of ['keydown','keypress','keyup'])target.dispatchEvent(new KeyboardEvent(type,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
  return {ready:true};
 },args:[text]});
 if(r?.result?.ready){ready=true;break;}
 }
 }
 await new Promise(r=>setTimeout(r,600));
 }
 if(!ready)throw Error('Product Search ne présente pas le champ MCRSearchString. Vérifie la connexion D365 et l’onglet ouvert, puis relance le clic droit.');
 await chrome.storage.local.remove('toolboxContextError');
 return {tabId:tab.id,text};
 }finally{productSearchBusy=false;}
}
