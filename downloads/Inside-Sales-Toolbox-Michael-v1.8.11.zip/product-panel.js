(()=>{
 const el=id=>document.getElementById(id);let current=null;
 function render(r){
  current=r;el('product-status').textContent=r?.message||'Sélectionne un SKU sur une page, puis clic droit → Rechercher dans D365.';
  el('product-submit').disabled=r?.state==='loading';el('product-open').hidden=!r?.tabId;
  if(r?.query&&document.activeElement!==el('product-query'))el('product-query').value=r.query;
  const root=el('product-results');root.replaceChildren();if(r?.state!=='done')return;
  if(!r.rows.length){root.textContent='Aucun produit retourné par D365.';return;}
  const note=document.createElement('p');note.className='muted';note.textContent=(r.total!==null&&r.total!==undefined?r.total+' produit(s) retourné(s). ':'')+r.rows.length+' ligne(s) affichée(s).';root.append(note);
  const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
  const headers=r.headers.map(normalize);
  const index=pattern=>{const matches=headers.map((v,i)=>pattern.test(v)?i:-1).filter(i=>i>=0);return matches.length===1?matches[0]:-1;};
  const columns={sku:index(/^(productname|nomduproduit)$/),item:index(/^(itemnu|itemnumber|numerodarticle|numerodart)/),brand:index(/^(manufacturer|fabricant)$/),description:index(/^(description)$/),warehouse:index(/^(warehouse|entrepot)$/),location:index(/^(location|emplacement)$/),available:index(/^(availablephysical|disponiblephysique|physiquedisponible)/),physical:index(/^(physicalinventory|inventairephysique|stockphysique)$/),reserved:index(/^(physicalreserved|physiquereserve|reservephysique)$/),ordered:index(/^(orderedintotal|commandetotal|totalcommande)$/)};
  const get=(row,key)=>columns[key]>=0?row[columns[key]]||'':'';
  function node(tag,className,text){const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;}
  function number(value){if(!value.trim())return null;const cleaned=value.replace(/[ \u00a0\u202f]/g,'');if(!/^-?\d+(?:[.,]\d+)?$/.test(cleaned))return null;return Number(cleaned.replace(',','.'));}
  const list=node('div','product-card-list');
  for(const row of r.rows){
   const card=node('article','product-card');
   const sku=get(row,'sku')||get(row,'item')||'Article D365';
   const heading=node('div','product-card-heading');heading.append(node('h3','product-sku',sku));
   const available=get(row,'available'),quantity=number(available);
   const badge=node('span','product-stock-badge'+(quantity!==null&&quantity>0?' product-stock-positive':''),quantity!==null&&quantity>0?'Disponible':quantity===0?'Disponible : 0':quantity!==null?'Disponible : '+available:'À vérifier');heading.append(badge);card.append(heading);
   const meta=[get(row,'brand'),get(row,'item')?'Article '+get(row,'item'):''].filter(Boolean).join(' · ');if(meta)card.append(node('p','product-meta',meta));
   if(get(row,'description'))card.append(node('p','product-description',get(row,'description')));
   const place=node('div','product-place');for(const [key,label] of [['warehouse','Entrepôt'],['location','Emplacement']]){if(get(row,key))place.append(node('span','',label+' : '+get(row,key)));}if(place.childNodes.length)card.append(place);
   const metrics=node('dl','product-metrics');for(const [key,label] of [['available','Disponible physique'],['physical','Inventaire physique'],['reserved','Réservé physique']]){const box=node('div','');box.append(node('dt','',label),node('dd',get(row,key)?'':'product-missing',get(row,key)||'Non renseigné'));metrics.append(box);}card.append(metrics);
   if(get(row,'ordered'))card.append(node('p','product-orders','Commandé au total : '+get(row,'ordered')));
   const details=node('details','product-details');details.append(node('summary','','Toutes les informations'));const values=node('dl','product-all-values');
   r.headers.forEach((label,i)=>{const pair=node('div','');pair.append(node('dt','',label),node('dd',row[i]?'':'product-missing',row[i]||'Non renseigné'));values.append(pair);});details.append(values);card.append(details);list.append(card);
  }
  root.append(list);
 }
 el('product-form').onsubmit=async e=>{e.preventDefault();const text=el('product-query').value.trim();if(!text)return;el('product-submit').disabled=true;try{const r=await chrome.runtime.sendMessage({kind:'productSearch',text});if(r?.error)el('product-status').textContent=r.error;}catch(e){el('product-status').textContent=e.message;}finally{el('product-submit').disabled=false;}};
 el('product-open').onclick=async()=>{if(current?.tabId){try{const t=await chrome.tabs.update(current.tabId,{active:true});await chrome.windows.update(t.windowId,{focused:true});}catch{el('product-status').textContent='L’onglet D365 a été fermé. Relance la recherche.';}}};
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.toolboxProductSearch)render(changes.toolboxProductSearch.newValue);});
 chrome.storage.local.get('toolboxProductSearch').then(s=>render(s.toolboxProductSearch));
})();
