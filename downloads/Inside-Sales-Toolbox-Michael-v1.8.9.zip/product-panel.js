(()=>{
 const el=id=>document.getElementById(id);let current=null;
 function render(r){
  current=r;el('product-status').textContent=r?.message||'Sélectionne un SKU sur une page, puis clic droit → Rechercher dans D365.';
  el('product-submit').disabled=r?.state==='loading';el('product-open').hidden=!r?.tabId;
  if(r?.query&&document.activeElement!==el('product-query'))el('product-query').value=r.query;
  const root=el('product-results');root.replaceChildren();if(r?.state!=='done')return;
  if(!r.rows.length){root.textContent='Aucun produit retourné par D365.';return;}
  const note=document.createElement('p');note.className='muted';note.textContent=(r.total!==null&&r.total!==undefined?r.total+' produit(s) retourné(s). ':'')+r.rows.length+' ligne(s) affichée(s).';root.append(note);
  const wrap=document.createElement('div');wrap.className='product-table-wrap';const table=document.createElement('table'),head=document.createElement('thead'),tr=document.createElement('tr');
  for(const name of r.headers){const th=document.createElement('th');th.textContent=name;tr.append(th);}head.append(tr);table.append(head);const body=document.createElement('tbody');
  for(const row of r.rows){const tr=document.createElement('tr');for(const value of row){const td=document.createElement('td');td.textContent=value||'Non renseigné';if(!value)td.className='product-empty';tr.append(td);}body.append(tr);}table.append(body);wrap.append(table);root.append(wrap);
 }
 el('product-form').onsubmit=async e=>{e.preventDefault();const text=el('product-query').value.trim();if(!text)return;el('product-submit').disabled=true;try{const r=await chrome.runtime.sendMessage({kind:'productSearch',text});if(r?.error)el('product-status').textContent=r.error;}catch(e){el('product-status').textContent=e.message;}finally{el('product-submit').disabled=false;}};
 el('product-open').onclick=async()=>{if(current?.tabId){try{const t=await chrome.tabs.update(current.tabId,{active:true});await chrome.windows.update(t.windowId,{focused:true});}catch{el('product-status').textContent='L’onglet D365 a été fermé. Relance la recherche.';}}};
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.toolboxProductSearch)render(changes.toolboxProductSearch.newValue);});
 chrome.storage.local.get('toolboxProductSearch').then(s=>render(s.toolboxProductSearch));
})();
