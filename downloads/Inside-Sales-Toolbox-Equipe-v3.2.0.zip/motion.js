// Visible interaction feedback, bounded to a few elements and never looping.
(()=>{
 const active=new WeakMap(),disclosures=new WeakMap();
 const reduced=()=>globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches===true;
 function animate(element,frames,options){
  if(!element?.animate||reduced())return;
  active.get(element)?.cancel();
  const animation=element.animate(frames,{duration:160,easing:'cubic-bezier(.2,.7,.2,1)',...options});active.set(element,animation);
  animation.finished.then(()=>{if(active.get(element)===animation)active.delete(element);},()=>{});return animation;
 }
 function cascade(element){
  const rows=[...element?.querySelectorAll?.('.record-row,.product-card,.tool-tile')||[]].slice(0,7);
  rows.forEach((row,i)=>animate(row,[{opacity:0,transform:'translateY(14px)'},{opacity:1,transform:'translateY(0)'}],{duration:300,delay:40+i*32,fill:'backwards'}));
 }
 function enter(element){const a=animate(element,[{opacity:.12,transform:'translateX(18px)'},{opacity:1,transform:'translateX(0)'}],{duration:320});cascade(element);return a;}
 function results(element){const a=animate(element,[{opacity:.45,transform:'translateY(6px)'},{opacity:1,transform:'translateY(0)'}],{duration:240});cascade(element);return a;}
 function navigation(button){return animate(button?.querySelector?.('svg'),[{transform:'scale(.75) rotate(-8deg)'},{transform:'scale(1.14) rotate(3deg)',offset:.6},{transform:'scale(1) rotate(0)'}],{duration:380});}
 function toggle(details){
  const previous=disclosures.get(details),opening=previous?!previous.opening:!details.open;
  const start=details.getBoundingClientRect().height,original=previous?.original||{height:details.style.height,overflow:details.style.overflow};
  previous?.animation.cancel();details.style.height='';details.style.overflow='';details.open=true;
  const css=getComputedStyle(details),summary=details.querySelector('summary');
  const collapsed=summary.getBoundingClientRect().height+['paddingTop','paddingBottom','borderTopWidth','borderBottomWidth'].reduce((n,k)=>n+(parseFloat(css[k])||0),0);
  const end=opening?details.getBoundingClientRect().height:collapsed;
  if(!details.animate){details.open=opening;return;}
  details.style.overflow='hidden';
  const animation=details.animate([{height:start+'px'},{height:end+'px'}],{duration:280,easing:'cubic-bezier(.2,.7,.2,1)',fill:'forwards'}),entry={animation,opening,original};disclosures.set(details,entry);
  animation.finished.then(()=>{
   if(disclosures.get(details)!==entry)return;
   details.open=opening;details.style.height=original.height;details.style.overflow=original.overflow;animation.cancel();disclosures.delete(details);
  },()=>{});
 }
 document.addEventListener('click',event=>{
  if(reduced())return;
  const button=event.target.closest?.('button');
  if(button&&!button.closest?.('.module-tabs'))animate(button,[{transform:'scale(1)'},{transform:'scale(.96)',offset:.3},{transform:'scale(1)'}],{duration:240});
  if(event.defaultPrevented)return;
  const summary=event.target.closest?.('summary'),details=summary?.parentElement;
  if(!details||details.tagName!=='DETAILS'||details.classList.contains('used-facet')||event.target.closest('a,button,input,select,textarea'))return;
  if(!details.animate)return;event.preventDefault();toggle(details);
 });
 document.addEventListener('toggle',event=>{
  const details=event.target;
  if(details?.open&&details.classList?.contains('used-facet')){
   const popover=details.querySelector('.facet-popover');
   animate(popover,[{opacity:0,transform:'translateY('+((details.dataset.direction==='up')?10:-10)+'px) scale(.97)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:240});
  }
 },true);
 globalThis.ToolboxMotion={enter,results,navigation};
})();
