(()=>{
 const el=id=>document.getElementById(id);let data=null,status={},visibleLimit=80;
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const {node,row:recordRow,fieldList,diagnostics,time,link}=ToolboxList;
 const numeric=s=>{const v=String(s||'').replace(/[\s\u00a0\u202f]/g,'');return /^-?\d+(?:[.,]\d+)?$/.test(v)?Number(v.replace(',','.')):null;};
 function render(){
  const root=el('used-results');root.replaceChildren();el('used-refresh').disabled=status.state==='loading';
  el('used-status').textContent=status.state==='loading'?(status.message||'Lecture de l’inventaire usagé…'):status.state==='error'?status.message:data?'Lecture terminée.':'Clique sur Actualiser pour récupérer le catalogue usagé.';
  el('used-stop').hidden=status.state!=='loading';el('used-more').hidden=true;
  el('used-time').textContent=data?time(data.at):'';
  el('used-status').dataset.state=status.state||'idle';el('used-status').hidden=!!data&&status.state!=='loading'&&status.state!=='error';
  if(!data){el('used-count').textContent='';el('used-currency').textContent='';el('used-coverage').textContent='';return;}
  const headers=data.headers.map(norm),index=rx=>headers.findIndex(v=>rx.test(v));
  const cols={item:index(/^(d365itemid|d365itemnumber|itemnumber)$/),sku:index(/^sku$/),description:index(/^description$/),brand:index(/^manufacturer$/),category:index(/^category$/),sub:index(/^subcategory$/),available:index(/^qtyavailable$/),owned:index(/^qtyowned$/),sellable:index(/^maxqtytosell$/),price:index(/^sellprice$/),model:index(/^model$/)};
  const get=(r,key)=>cols[key]>=0?r.values[cols[key]]||'':'';
  const query=norm(el('used-query').value),availableOnly=el('used-available').checked;
  const records=data.rows.filter(r=>(!query||norm(r.values.join(' ')).includes(query))&&(!availableOnly||numeric(get(r,'available'))>0));
  const groups=new Map();records.forEach((r,i)=>{const key=get(r,'item').trim()?'item:'+get(r,'item').trim():'sku:'+get(r,'sku')+':'+i;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);});
  el('used-count').textContent=groups.size+' article(s) · '+records.length+' / '+data.rows.length+' ligne(s)';
  el('used-currency').textContent=data.currency||'Devise à vérifier';
  el('used-coverage').textContent=data.complete?'Catalogue complet · total vérifié':data.loadedToEnd&&Number.isFinite(data.expected)&&data.rows.length<data.expected?'Lecture partielle · '+data.rows.length+' / '+data.expected+' lignes annoncées':data.loadedToEnd?'Fin du tableau atteinte · total non confirmé':'Catalogue partiel · relance Actualiser';
  el('used-more').hidden=groups.size<=visibleLimit;
  for(const rows of [...groups.values()].slice(0,visibleLimit)){
   const r=rows[0],meta=[];
   if(rows.length===1){for(const [key,label] of [['available','Dispo.'],['owned','Possédé'],['sellable','Max.']])if(get(r,key)!=='')meta.push({label,value:get(r,key),positive:key==='available'&&numeric(get(r,key))>0});}
   else meta.push({value:rows.length+' lignes source',raw:false});
   const prices=[...new Set(rows.map(r=>get(r,'price')).filter(Boolean))];
   const amount=prices.length===1?prices[0]+(data.currency?' '+data.currency:''):'';
   if(prices.length>1)meta.push({value:'Plusieurs prix',raw:false});
   const name=[get(r,'brand'),get(r,'item')?'D365 '+get(r,'item'):''].filter(Boolean).join(' · ');
   const record=recordRow({key:'used:'+get(r,'item')+':'+get(r,'sku'),code:get(r,'sku')||get(r,'item'),name,description:get(r,'description'),amount,meta});
   rows.forEach((r,i)=>{if(rows.length>1)record.append(node('h4','record-source-heading','Ligne source '+(i+1)));record.append(fieldList(data.headers,r.values));if(r.href)record.append(link('Ouvrir le lien SKU ↗',r.href,'record-source-link'));});
   root.append(record);
  }
  if(!records.length)root.append(node('p','muted','Aucun article ne correspond aux filtres locaux.'));
 }
 async function action(kind){try{const r=await chrome.runtime.sendMessage({kind});if(r?.error)throw Error(r.error);if(kind==='usedPowerBIDiagnostic'){diagnostics('used-diagnostic-output',r.value);}if(kind==='usedPowerBIBind')el('used-status').textContent='Onglet associé. Clique sur Actualiser.';}catch(e){el('used-status').textContent=e.message;}}
 el('used-refresh').onclick=()=>action('usedPowerBIRead');el('used-open').onclick=()=>action('usedPowerBIOpen');el('used-bind').onclick=()=>action('usedPowerBIBind');el('used-diagnostic').onclick=()=>action('usedPowerBIDiagnostic');
 el('used-query').oninput=()=>{visibleLimit=80;render();};el('used-available').onchange=()=>{visibleLimit=80;render();};
 el('used-more').onclick=()=>{visibleLimit+=80;render();};
 el('used-stop').onclick=()=>action('usedPowerBIStop');
 el('used-clear').onclick=async()=>{await chrome.storage.local.remove('toolboxUsedPowerBI');data=null;render();};
 chrome.storage.onChanged.addListener((c,area)=>{if(area!=='local')return;let changed=false;if(c.toolboxUsedPowerBI){data=c.toolboxUsedPowerBI.newValue;changed=true;}if(c.toolboxUsedPowerBIStatus){status=c.toolboxUsedPowerBIStatus.newValue||{};changed=true;}if(c.toolboxUsedPowerBIDiagnostic){diagnostics('used-diagnostic-output',c.toolboxUsedPowerBIDiagnostic.newValue);}if(changed)render();});
 chrome.storage.local.get(['toolboxUsedPowerBI','toolboxUsedPowerBIStatus']).then(s=>{data=s.toolboxUsedPowerBI;status=s.toolboxUsedPowerBIStatus||{};render();});
})();
