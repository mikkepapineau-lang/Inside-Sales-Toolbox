// Presentation only: one running action, explicit outcomes, no extra CRM calls.
(()=>{
 const entries=new Map();let running=false;
 const el=id=>document.getElementById(id),node=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!==undefined)n.textContent=text;return n;};
 function label(entry,text,state){
  const {button}=entry;button.dataset.actionState=state;const mark=node('span','action-mark');mark.setAttribute('aria-hidden','true');
  if(state==='busy'){for(let i=0;i<3;i++)mark.append(node('i',''));}else mark.textContent=state==='success'?'✓':state==='warning'?'!':state==='error'?'!':'';
  button.replaceChildren(mark,node('span','action-label',text));
 }
 function feedback(entry,text,state){const p=el(entry.id+'-feedback');if(!p)return;p.hidden=false;p.dataset.state=state;p.replaceChildren(node('span','action-feedback-mark',state==='busy'?'':state==='success'?'✓':'!'),node('span','action-feedback-copy',text));p.firstChild.setAttribute('aria-hidden','true');globalThis.ToolboxMotion?.text(p);if(state!=='busy')globalThis.ToolboxMotion?.success(p.firstChild);}
 function reset(id,hideFeedback=true){const e=entries.get(id);if(!e)return;clearTimeout(e.timer);e.button.replaceChildren(...e.original.map(n=>n.cloneNode(true)));delete e.button.dataset.actionState;e.button.removeAttribute('aria-busy');const p=el(id+'-feedback');if(p&&hideFeedback)p.hidden=true;}
 function bind(id,config){
  const button=el(id),task=button?.onclick;if(!task)return;const entry={id,button,config,original:[...button.childNodes].map(n=>n.cloneNode(true)),timer:null};entries.set(id,entry);
  button.onclick=async()=>{
   if(running||button.disabled)return;running=true;clearTimeout(entry.timer);
   const locks=[...document.querySelectorAll('#tool-bridge button,[data-step]')].filter(b=>b!==button).map(b=>({b,disabled:b.disabled}));for(const {b}of locks)b.disabled=true;
   button.disabled=true;button.setAttribute('aria-busy','true');el('tool-bridge').setAttribute('aria-busy','true');label(entry,config.busy,'busy');feedback(entry,config.busy,'busy');
   let result,state='error';
   try{
    result=await task();if(result?.toolboxError)throw Error(result.toolboxError);
    state=config.state?.(result)||'success';label(entry,state==='warning'?'Vérification requise':config.done,state);feedback(entry,state==='warning'?(config.warning||'Vérifie le résultat dans D365.'):config.message,state);
    globalThis.ToolboxMotion?.success(button.querySelector('.action-mark'));
    if(state==='success'){config.after?.(result);globalThis.ToolboxMotion?.success(el('bridge-next'));}
   }catch(e){result={toolboxError:e.message};label(entry,'À réessayer','error');feedback(entry,e.message,'error');}
   finally{
    button.removeAttribute('aria-busy');el('tool-bridge').removeAttribute('aria-busy');for(const {b,disabled}of locks)if(b.disabled)b.disabled=disabled;
    const terminal=state!=='error'&&config.terminal?.(result);button.disabled=!!terminal;running=false;
    if(!terminal)entry.timer=setTimeout(()=>reset(id,false),2800);
   }
   return result;
  };
 }
 globalThis.BridgeActions={bind,reset,get busy(){return running;}};
})();
