(()=>{
 const el=id=>document.getElementById(id),day=()=>ToolboxUsedCatalogue.day(Date.now());let daily={},busy=false,problem='',feedbackTimer,loading=true;
 function render(){
  el('workspace-prep').hidden=loading||!busy&&!problem&&daily.date===day();el('workspace-start').disabled=busy;el('workspace-open').disabled=busy;el('workspace-dismiss').disabled=busy;
  el('workspace-prep-state').textContent=problem||(busy?'Ouverture et regroupement des onglets…':'D365 · Product Search · 2 rapports Power BI');
  el('workspace-prep').dataset.state=problem?'error':busy?'loading':'ready';
 }
 async function refresh(){try{daily=(await chrome.storage.local.get('toolboxWorkspaceDay')).toolboxWorkspaceDay||{};}finally{loading=false;render();}}
 async function start(){
  if(busy)return;busy=true;problem='';render();
  try{
   await ToolboxAccess.requireAccess({origins:['https://solotech.operations.dynamics.com/*','https://app.powerbi.com/*']},'D365 et Power BI');
   const current=await chrome.windows.getCurrent(),response=await chrome.runtime.sendMessage({kind:'workspacePrepare',windowId:current.id});if(response?.error)throw Error(response.error);if(!response?.value)throw Error('La préparation n’a pas été confirmée. Réessaie.');
   daily={date:day(),status:'prepared'};
   const feedback=el('workspace-feedback');feedback.textContent=response.value.total+' onglets ouverts ou réutilisés · groupe réduit.';feedback.hidden=false;globalThis.ToolboxMotion?.enter(feedback);clearTimeout(feedbackTimer);feedbackTimer=setTimeout(()=>feedback.hidden=true,3500);
  }catch(e){problem=e.message;}finally{busy=false;render();}
 }
 el('workspace-start').onclick=start;el('workspace-open').onclick=start;
 el('workspace-dismiss').onclick=async()=>{try{daily={date:day(),status:'dismissed'};problem='';await chrome.storage.local.set({toolboxWorkspaceDay:daily});render();}catch(e){problem=e.message;render();}};
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.toolboxWorkspaceDay){daily=changes.toolboxWorkspaceDay.newValue||{};render();}});
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refresh().catch(()=>{});});window.addEventListener('focus',()=>refresh().catch(()=>{}));refresh().catch(()=>{});
})();
