// DOM-only extraction. No tokens, cookies, private API or report internals.
(()=>{
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const text=e=>String(e?.innerText||e?.textContent||e?.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim();
 const visible=e=>!!e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none';
 function tables(){
  const nodes=[...document.querySelectorAll('[role="grid"],[role="table"],table,.tableEx')].filter(visible);
  return nodes.map(root=>{
   let headings=[...root.querySelectorAll('[role="columnheader"],thead th,.columnHeader')];
   headings=headings.filter(e=>!headings.some(other=>other!==e&&e.contains(other)));
   const headers=headings.map(text),keys=headers.map(norm);
   const order=keys.findIndex(v=>/^(d365itemid|d365itemnumber|itemnumber)$/.test(v));
   const sku=keys.findIndex(v=>v==='sku'),available=keys.findIndex(v=>v==='qtyavailable');
   const customer=keys.findIndex(v=>v==='description');
   return {root,headers,order,customer,sku,available};
  }).filter(t=>t.sku>=0&&t.available>=0&&t.customer>=0).filter((t,_,all)=>!all.some(o=>o!==t&&t.root.contains(o.root)));
 }
 function rows(t){
  const records=[];
  for(const row of t.root.querySelectorAll('[role="row"],tr,.row')){
   if(!visible(row))continue;
   let cells=[...row.querySelectorAll('[role="gridcell"],[role="cell"],td,.cell')];
   cells=cells.filter(e=>!cells.some(other=>other!==e&&e.contains(other)));
   if(!cells.length)continue;
   const values=Array(t.headers.length).fill('');
   const indexed=cells.every(e=>Number(e.getAttribute('aria-colindex'))>0);
   if(!indexed&&cells.length!==t.headers.length)continue;
   cells.forEach((cell,i)=>{const j=indexed?Number(cell.getAttribute('aria-colindex'))-1:i;if(j<values.length)values[j]=text(cell);});
   if(!values[t.sku]||/^(total|totaux)$/i.test(values[t.sku]))continue;
   const link=[...row.querySelectorAll('a[href]')].find(a=>text(a)===values[t.sku]);
   let href='';try{const u=new URL(link?.getAttribute('href')||'',location.href);if(link&&u.protocol==='https:'&&!u.username&&!u.password)href=u.href;}catch{}
   records.push({values,href});
  }
  return records;
 }
 const regionNames=['CANADA','UK','USA'];
 function regionControls(){
  const boxes=[...document.querySelectorAll('.visualContainer,.slicerContainer,[data-visualtype="slicer"],[role="group"],[role="listbox"]')].filter(visible);
  const matches=boxes.map(root=>{
   const heading=[root,...root.querySelectorAll('[aria-label],[title],h1,h2,h3,h4,.slicer-header-text,.visualTitle')].some(e=>/^(subregion|sousregion)$/.test(norm(e.getAttribute?.('aria-label')||e.getAttribute?.('title')||text(e))));
   if(!heading&&!/\bSUBREGION\b/i.test(text(root)))return null;
   const options=[...root.querySelectorAll('[role="option"],[role="checkbox"],[role="button"],button,.slicerItemContainer')].filter(e=>visible(e)&&regionNames.includes(text(e).toUpperCase()));
   const unique=options.filter(e=>!options.some(other=>other!==e&&e.contains(other)));
   const controls=regionNames.map(name=>{const found=unique.filter(e=>text(e).toUpperCase()===name);return found.length===1?found[0]:null;});
   return controls.every(Boolean)?{root,controls}:null;
  }).filter(Boolean);
  const unique=matches.filter(m=>!matches.some(other=>other!==m&&m.root.contains(other.root)));return unique.length===1?unique[0]:null;
 }
 function regionState(){
  const group=regionControls();if(!group)return {verified:false,selected:[],reason:'Sélecteur SUBREGION introuvable ou ambigu.'};
  const states=group.controls.map(control=>{let e=control;for(let depth=0;e&&depth<3;depth++,e=e.parentElement){for(const attr of ['aria-selected','aria-checked','aria-pressed','data-selected']){const value=e.getAttribute?.(attr);if(value==='true'||value==='false')return value==='true';}if(e.tagName==='INPUT'&&e.type==='checkbox')return e.checked;}return null;});
  if(states.some(v=>v===null))return {verified:false,selected:[],reason:'L’état du sélecteur SUBREGION n’est pas accessible.'};
  const empty=states.every(v=>v===false),selected=empty?[...regionNames]:regionNames.filter((_,i)=>states[i]);return {verified:true,selected,empty};
 }
 async function ensureRegion(region='ALL'){
  const desired=region==='ALL'?[...regionNames]:regionNames.includes(region)?[region]:null;if(!desired)throw Error('Sous-région invalide.');
  const same=state=>state.verified&&JSON.stringify([...state.selected].sort())===JSON.stringify([...desired].sort());
  let state=regionState();if(!state.verified)throw Error(state.reason+' Ouvre le filtre dans Power BI, puis utilise Diagnostic inventaire usagé.');
  for(let attempt=0;attempt<7&&!same(state);attempt++){
   const group=regionControls();if(!group)throw Error('Le sélecteur SUBREGION a changé.');
   let name=state.empty&&desired.length===1?desired[0]:regionNames.find(n=>state.selected.includes(n)!==desired.includes(n));
   const control=group.controls[regionNames.indexOf(name)];if(!control||control.disabled||control.getAttribute('aria-disabled')==='true')throw Error('La sous-région ne peut pas être sélectionnée.');
   const before=JSON.stringify(state.selected);control.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,ctrlKey:!state.empty}));
   const deadline=Date.now()+2500;do{await new Promise(r=>setTimeout(r,150));state=regionState();if(!state.verified)throw Error(state.reason);if(JSON.stringify(state.selected)!==before)break;}while(Date.now()<deadline);
   if(JSON.stringify(state.selected)===before)throw Error('La sélection SUBREGION ne répond pas. Aucun relevé régional n’a été enregistré.');
  }
  if(!same(state))throw Error('La sous-région sélectionnée ne correspond pas à la demande.');
  const start=Date.now(),deadline=start+15000;let stable=0,previous='';
  do{
   await new Promise(r=>setTimeout(r,300));if(!same(regionState()))throw Error('La sous-région a changé pendant son chargement.');
   const table=tables()[0],signature=table?JSON.stringify([table.headers,rows(table).slice(0,4).map(r=>r.values)]):'';
   if(!diagnostic().busy&&signature&&signature===previous)stable++;else stable=0;previous=signature;
   if(stable>=3&&Date.now()-start>=2000)return desired;
  }while(Date.now()<deadline);
  throw Error('La mise à jour du tableau après sélection de la sous-région n’est pas confirmée.');
 }
 function diagnostic(){return {subregion:regionState(),tables:tables().map(t=>({headers:t.headers,rowCount:rows(t).length})),gridCount:document.querySelectorAll('[role="grid"],[role="table"],table,.tableEx').length,frame:location.origin,readyLabel:tables().length===1,currency:(String(document.body?.innerText||'').match(/Display\s+Currency\s+(CAD|USD|EUR|GBP)\b/i)||[])[1]||'',busy:!!document.querySelector('[aria-busy="true"]')};}
 async function ensureReady(){
  if(diagnostic().readyLabel)return;
  const name=e=>[text(e),e.getAttribute('aria-label'),e.getAttribute('title')].filter(Boolean).some(s=>/^LP\s+Catalog\s*[-–]\s*Used\s+Gear$/i.test(String(s).trim()));
  let unique=[];const loadingDeadline=Date.now()+12000;
  do{
   if(diagnostic().readyLabel)return;
   const candidates=[...document.querySelectorAll('[role="tab"],[role="treeitem"],button,a,[role="button"],.navigationItem')].filter(e=>visible(e)&&name(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true');
   unique=candidates.filter(e=>!candidates.some(other=>other!==e&&e.contains(other)));
   if(unique.length)break;
   await new Promise(r=>setTimeout(r,250));
  }while(Date.now()<loadingDeadline);
  if(unique.length!==1)throw Error('La page LP Catalog - Used Gear ne peut pas être sélectionnée automatiquement ('+unique.length+' cible). Ouvre le panneau des pages du rapport ou utilise Diagnostic Power BI.');
  unique[0].click();
  const deadline=Date.now()+12000;
  while(Date.now()<deadline){if(diagnostic().readyLabel&&!diagnostic().busy){await new Promise(r=>setTimeout(r,500));return;}await new Promise(r=>setTimeout(r,250));}
  throw Error('LP Catalog - Used Gear a été sélectionné, mais son chargement n’est pas confirmé. Réessaie après le chargement.');
 }
 let scan=null;
 const scope=()=>JSON.stringify({regions:regionState(),filters:[...document.querySelectorAll('[role="combobox"]')].filter(visible).map(text)});
 function restore(){if(scan)for(const [e,top,left] of scan.saved){e.scrollTop=top;e.scrollLeft=left;e.dispatchEvent(new Event('scroll',{bubbles:true}));}}
 function cancel(){restore();scan=null;return {cancelled:true};}
 async function read(){
  cancel();
  const candidates=tables();if(candidates.length!==1)return {error:candidates.length?'Plusieurs tableaux d’inventaire usagé détectés. Affiche uniquement LP Catalog - Used Gear.':'Tableau d’inventaire usagé non accessible. Ouvre LP Catalog - Used Gear; au besoin, sélectionne le tableau et utilise Alt + Maj + F11.',diagnostic:diagnostic()};
  if(diagnostic().busy)return {error:'Power BI charge encore le rapport. Réessaie après le chargement.',diagnostic:diagnostic()};
  const t=candidates[0],scrollers=[t.root,...t.root.querySelectorAll('*')].filter(e=>e.clientHeight>40&&e.scrollHeight>e.clientHeight+5);
  const declared=Number(t.root.getAttribute('aria-rowcount'));
  const headerRows=[...t.root.querySelectorAll('[role="row"],tr')].filter(e=>e.querySelector('[role="columnheader"],th')).length;
  const expected=Number.isInteger(declared)&&declared>0?Math.max(0,declared-headerRows):null;
  scan={regions:regionState().verified?regionState().selected:null,t,scrollers,saved:scrollers.map(e=>[e,e.scrollTop,e.scrollLeft]),collected:new Map(),scope:scope(),currency:diagnostic().currency,steps:0,endStable:0,lastEnd:'',stalled:0,expected};
  scrollers.forEach(e=>{e.scrollTop=0;e.dispatchEvent(new Event('scroll',{bubbles:true}));});
  await new Promise(r=>setTimeout(r,500));return next();
 }
 async function next(){
  if(!scan)throw Error('La lecture du catalogue a été interrompue. Relance Actualiser.');
  const deadline=Date.now()+6500;
  try{
   do{
    if(scope()!==scan.scope||diagnostic().currency!==scan.currency||tables()[0]?.root!==scan.t.root)throw Error('Les filtres ou le tableau ont changé pendant la lecture. Relance Actualiser.');
    if(diagnostic().busy){await new Promise(r=>setTimeout(r,400));continue;}
    for(const r of rows(scan.t))scan.collected.set(JSON.stringify(r.values),r);
    const before=scan.scrollers.map(e=>e.scrollTop);
    const atEnd=scan.scrollers.every(e=>e.scrollTop+e.clientHeight>=e.scrollHeight-2);
    if(atEnd){
     const signature=JSON.stringify([scan.collected.size,scan.scrollers.map(e=>e.scrollHeight)]);
     scan.endStable=signature===scan.lastEnd?scan.endStable+1:0;scan.lastEnd=signature;
     if(scan.endStable>=3){
      if(!scan.collected.size)throw Error('Aucune ligne d’inventaire lisible. Cela ne confirme pas l’absence d’articles.');
      const complete=scan.expected!==null&&scan.expected===scan.collected.size;
      const result={regions:scan.regions,headers:scan.t.headers,rows:[...scan.collected.values()],currency:scan.currency,filters:scan.scope,steps:scan.steps,loadedToEnd:true,expected:scan.expected,complete,partial:!complete,more:false,diagnostic:diagnostic()};
      restore();scan=null;return result;
     }
    }else{
     scan.endStable=0;scan.scrollers.forEach(e=>{e.scrollTop+=Math.max(40,e.clientHeight*.75);e.dispatchEvent(new Event('scroll',{bubbles:true}));});scan.steps++;
     scan.stalled=scan.scrollers.every((e,i)=>e.scrollTop===before[i])?scan.stalled+1:0;
     if(scan.stalled>=6)throw Error('Le défilement Power BI ne progresse plus. Le chargement complet n’est pas confirmé.');
    }
    await new Promise(r=>setTimeout(r,350));
   }while(Date.now()<deadline);
   return {regions:scan.regions,more:true,count:scan.collected.size,expected:scan.expected,steps:scan.steps,diagnostic:diagnostic()};
  }catch(e){cancel();throw e;}
 }
 globalThis.ToolboxUsedPowerBIReader={read,next,cancel,diagnostic,ensureReady,regionState,ensureRegion};
})();
